module.exports = {
  jwtSecretKey: 'itheima No1',
  // token 保留时间
  expiresIn: '10h',
  // 数据库信息
  DADTEBASE: {
    host: 'localhost',
    datebase: 'blog',
    user: 'root',
    password: '123456',
  },
}
